def increase(num):
    return num+1